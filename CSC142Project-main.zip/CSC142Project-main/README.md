# CSC142Project  
These projects are from CSC142 Java class.              

Project name:   

Project 1: Console-based Plotting  

Project 2: Draw Curves from Straight Lines   

Project 3: Area Under Curve: Sine Wave



