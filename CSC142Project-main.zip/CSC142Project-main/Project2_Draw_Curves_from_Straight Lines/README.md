Read the PDF first!!!

The website inspired me the most: https://www.mrsmilewski.com/parabolic-curve.html

• For descriptions of the technique and samples of output, see these sites:

site1 http://mathematicsrealm.blogspot.com/2012/07/curves-formed-from-straight-lines.html

site2 https://mathcraft.wonderhowto.com/how-to/create-parabolic-curves-using-straight-lines-0131301/
